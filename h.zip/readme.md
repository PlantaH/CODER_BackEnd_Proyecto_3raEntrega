# API DESCRIPTION

## VARIABLES .env

###     
    BASEDATOS = "mongodb"
    MONGO_CONEXION = ""
    SESSION_SECRET = "" 

    
    TWILIO_SID = ""
    TWILIO_TOKEN = ""

    NODEMMAILER_USER = ""
    NODEMAILER_PASS = "

    